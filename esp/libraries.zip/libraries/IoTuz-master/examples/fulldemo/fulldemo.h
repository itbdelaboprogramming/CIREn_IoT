#ifndef FULLDEMOH
#define FULLDEMOH

#include <IoTuz.h>
extern IoTuz iotuz;

#endif
